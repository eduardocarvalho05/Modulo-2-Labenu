import { HeaderContainer } from "./style"

export function Header() {
   return <HeaderContainer>
      <span>&#128640;   </span>
      <span> Jobs </span>
      <span> &#128640;</span>
   </HeaderContainer>
}