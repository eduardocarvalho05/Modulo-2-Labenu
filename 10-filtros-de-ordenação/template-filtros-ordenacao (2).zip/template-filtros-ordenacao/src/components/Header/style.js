import styled from "styled-components"

export const HeaderContainer = styled.h1`
   display: flex;
   justify-content: space-around;
`